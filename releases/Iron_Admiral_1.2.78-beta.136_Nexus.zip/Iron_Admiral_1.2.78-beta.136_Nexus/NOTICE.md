# Third-party components

Iron Admiral includes or builds on the following works. Each keeps its own licence, and the copies of those licences are in the `licenses/` folder.

| Component | Authors | Licence |
|---|---|---|
| Dreadnought Improvement Project "The Great Game" (DIP GG) | Brother Munro and the DIP team | Apache License 2.0 (`licenses/DIP_LICENSE_Apache-2.0.txt`) |
| TweaksAndFixes (TAF) | NathanKell, DukeDagor | MIT (`licenses/TweaksAndFixes_LICENSE_MIT.txt`) |
| MelonLoader | LavaGang | Apache License 2.0 (`licenses/MelonLoader_LICENSE_Apache-2.0.txt`) |
| Ultimate Admiral's Shippack (Nexus mod 45) | Badkapp / MarineWerft | free use with credit, not for paid mods (`Mods/IronAdmiralDesigns/Shippack/CREDITS.txt`) |
| CV Barebone Modification (carrier ship type, hull data, air wing design study - issue #104) | ChonkE (XxChonkExX) | MIT (`licenses/CVBarebone_LICENSE_MIT.txt`) |
| UAD Vanilla Plus (Nexus mod 58, github.com/gregorymostizky/UADVanillaPlus) - the approach of the continuous campaign map and other ideas, reimplemented | xxfivebyfivexx (GitHub: gregorymostizky) | borrowing allowed by the author with credit (README, "Borrowing Code") |
| Fleet Operations for Ultimate Admiral: Dreadnoughts 0.0.8.1 (github.com/MaoDDi/FleetOperations-UAD) - manual fleet aim, spread and salvo marks, ported into DIP_GG_Fixes | wangchuanyu666 (GitHub: MaoDDi) | MIT (`licenses/FleetOperations_LICENSE_MIT.txt`) |

Files taken from DIP GG and changed for Iron Admiral carry the author's changes under Apache License 2.0, section 4. The original DIP notices are kept. Where a file mixes DIP content with the author's changes, the DIP content stays under Apache License 2.0, and the author's changes are covered by LICENSE.md.

Iron Admiral versions up to and including 1.2.47 were released under the Apache License 2.0 as a whole.
