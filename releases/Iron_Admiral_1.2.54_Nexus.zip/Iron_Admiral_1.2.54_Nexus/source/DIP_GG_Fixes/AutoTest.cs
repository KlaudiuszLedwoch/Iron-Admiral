// 1.11.89: unattended battle test (author's tool, off by default). From the main menu it sets up a custom battle from the
// AutoTestBattle preference, runs it for AutoTestSeconds of real time at the requested speed, writes a summary line per ship to the
// log and quits the game. Format: "1916;germany:bb=4;usa:bb=1,ca=1,cl=3,dd=6" (year; player side; AI side).
using System;
using System.Collections;
using System.Collections.Generic;
using MelonLoader;
using UnityEngine;
using Il2Cpp;

namespace DipGgFixes
{
    internal static class AutoTest
    {
        internal static MelonPreferences_Entry<string> Spec;
        internal static MelonPreferences_Entry<float> Seconds, Speed;
        static bool started;

        internal static void CreatePrefs(MelonPreferences_Category cat)
        {
            Spec = cat.CreateEntry("AutoTestBattle", "", null, "Author's tool: unattended custom battle test from the main menu, e.g. 1916;germany:bb=4;usa:bb=1,ca=1,cl=3,dd=6 (empty = off). The game quits when the test ends.");
            Seconds = cat.CreateEntry("AutoTestSeconds", 900f, null, "Author's tool: real-time length of the unattended battle test (s)");
            Speed = cat.CreateEntry("AutoTestTimeScale", 4f, null, "Author's tool: Unity time scale during the unattended battle test");
        }

        static void Log(string m) { MelonLogger.Msg("[DIP GG Fixes][AutoTest] " + m); }

        internal static void Tick()
        {
            if (started || Spec == null || string.IsNullOrEmpty(Spec.Value)) return;
            bool menu = false; try { menu = GameManager.IsMainMenu && !GameManager.IsLoadingAny; } catch { }
            if (!menu || Time.realtimeSinceStartup < 20f) return;
            started = true;
            MelonCoroutines.Start(Run(Spec.Value));
        }

        static void Fill(Ui.SkirmishSetup.Player p, string side, int year)
        {
            var kv = side.Split(':');
            p.country = G.GameData.players[kv[0].Trim()];
            p.year = year;
            var am = p.shipAmounts;
            var keys = new List<ShipType>(); foreach (var x in am) keys.Add(x.Key);
            foreach (var k in keys) am[k] = 0;
            if (kv.Length > 1)
                foreach (var e in kv[1].Split(','))
                {
                    var q = e.Split('='); if (q.Length != 2) continue;
                    ShipType st; if (!G.GameData.shipTypes.TryGetValue(q[0].Trim(), out st)) { Log("unknown ship type " + q[0]); continue; }
                    am[st] = int.Parse(q[1].Trim());
                }
        }

        // TweaksAndFixes replaces the custom battle setup: its UiM.skirmishSetupMod holds one entry per ship class (Guid -> number of ships)
        static void FillTaf(string side, int year, bool first)
        {
            Type uim = null;
            foreach (var a in AppDomain.CurrentDomain.GetAssemblies()) { var t = a.GetType("TweaksAndFixes.UiM"); if (t != null) { uim = t; break; } }
            if (uim == null) { Log("TAF UiM not found"); return; }
            var mod = uim.GetField("skirmishSetupMod", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static).GetValue(null);
            var pl = mod.GetType().GetField(first ? "player1" : "player2").GetValue(mod);
            var amounts = (Dictionary<ShipType, Dictionary<Guid, int>>)pl.GetType().GetField("shipAmounts").GetValue(pl);
            var avail = (Dictionary<ShipType, bool>)pl.GetType().GetField("shipTypeAvailible").GetValue(pl);
            pl.GetType().GetField("year").SetValue(pl, year);
            var kv = side.Split(':');
            try { pl.GetType().GetField("player").SetValue(pl, G.GameData.players[kv[0].Trim()]); } catch { }
            foreach (var k in new List<ShipType>(amounts.Keys)) amounts[k].Clear();
            var sb = new System.Text.StringBuilder($"TAF {(first ? "player" : "enemy")}: ");
            if (kv.Length > 1)
                foreach (var e in kv[1].Split(','))
                {
                    var q = e.Split('='); ShipType st; if (q.Length != 2 || !G.GameData.shipTypes.TryGetValue(q[0].Trim(), out st)) continue;
                    var d = new Dictionary<Guid, int>(); d[Guid.NewGuid()] = int.Parse(q[1].Trim());
                    amounts[st] = d; avail[st] = true;
                    sb.Append($"{st.name}={q[1]} ");
                }
            Log(sb.ToString());
        }

        static IEnumerator Run(string spec)
        {
            Log("starting: " + spec);
            var parts = spec.Split(';');
            int year = int.Parse(parts[0].Trim());
            try { GameManager.Instance.ToCustomBattleSetup(); } catch (Exception e) { Log("ToCustomBattleSetup: " + e.Message); yield break; }
            float t0 = Time.realtimeSinceStartup;
            while (Time.realtimeSinceStartup < t0 + 60f) { bool ok = false; try { ok = GameManager.IsCustomBattleSetup && !GameManager.IsLoadingAny && G.ui.skirmishSetup != null; } catch { } if (ok) break; yield return null; }
            for (float w = Time.realtimeSinceStartup + 3f; Time.realtimeSinceStartup < w;) yield return null;
            Ui.SkirmishSetup setup = null;
            try
            {
                setup = G.ui.skirmishSetup;
                Fill(setup.player1, parts[1], year);
                Fill(setup.player2, parts[2], year);
                setup.Dirty();
                try { FillTaf(parts[1], year, true); FillTaf(parts[2], year, false); } catch (Exception e) { Log("TAF setup: " + e); }
                try { BattleManager.Instance.PreInitCustomBattle(setup); } catch (Exception e) { Log("PreInitCustomBattle: " + e.Message); }
                var sb0 = new System.Text.StringBuilder("amounts: "); foreach (var x in setup.player1.shipAmounts) sb0.Append($"P {(x.Key != null ? x.Key.name : "?")}={x.Value} "); foreach (var x in setup.player2.shipAmounts) sb0.Append($"AI {(x.Key != null ? x.Key.name : "?")}={x.Value} "); if (setup.player1.isHullAvailable != null) foreach (var x in setup.player1.isHullAvailable) sb0.Append($"hullP {(x.Key != null ? x.Key.name : "?")}={x.Value} "); Log(sb0.ToString());
                string why1, why2;
                bool can = BattleManager.Instance.CanStartCustomBattle(setup, false, out why1, out why2);
                Log($"setup filled: {parts[1]} vs {parts[2]}, year {year}; can start = {can} {why1} {why2}");
                BattleManager.Instance.StartCustomBattle(setup, false);
            }
            catch (Exception e) { Log("setup/start: " + e); Application.Quit(); yield break; }
            t0 = Time.realtimeSinceStartup;
            bool loaded = false; while (Time.realtimeSinceStartup < t0 + 2400f) { try { loaded = GameManager.IsBattle && !GameManager.IsLoadingAny && BattleManager.Instance.CurrentBattle != null && BattleManager.Instance.CurrentBattle.Ships != null && BattleManager.Instance.CurrentBattle.Ships.Count > 0; } catch { } if (loaded) break; yield return null; }
            if (!loaded) { Log("battle did not load within 40 min - quitting"); Application.Quit(); yield break; }
            Log("battle loaded after " + (Time.realtimeSinceStartup - t0).ToString("0") + " s");
            // the loading screen waits for "click to continue" and the first battle may open the help window: dismiss both
            for (float w = Time.realtimeSinceStartup + 3f; Time.realtimeSinceStartup < w;) yield return null;
            try { var b = G.ui.loadingUiButton; if (b != null) { b.onClick.Invoke(); Log("loading screen: continue pressed"); } } catch (Exception e) { Log("continue: " + e.Message); }
            try { G.ui.HideLoadingScreen(false, null); } catch (Exception e) { Log("hide loading: " + e.Message); }
            try { var h = G.ui.popupHelp; if (h != null) { h.SetActive(false); Log("help window closed"); } } catch (Exception e) { Log("help: " + e.Message); }
            try { Log("paused = " + TimeControl.IsPaused()); if (TimeControl.IsPaused()) TimeControl.Pause(false); } catch (Exception e) { Log("pause: " + e.Message); }
            float end = Time.realtimeSinceStartup + Seconds.Value; float next = 0f;
            while (Time.realtimeSinceStartup < end)
            {
                try { if (Time.timeScale < Speed.Value) Time.timeScale = Speed.Value; } catch { }
                if (Time.realtimeSinceStartup > next) { next = Time.realtimeSinceStartup + 60f; Summary("progress"); }
                bool inBattle = false; try { inBattle = GameManager.IsBattle; } catch { }
                if (!inBattle) { Log("battle ended before the time limit"); break; }
                yield return null;
            }
            Summary("final");
            Log("test finished - quitting");
            Application.Quit();
        }

        static void Summary(string tag)
        {
            try
            {
                var b = BattleManager.Instance != null ? BattleManager.Instance.CurrentBattle : null; if (b == null) return;
                var ships = b.Ships; if (ships == null) return;
                var sb = new System.Text.StringBuilder($"{tag} t={Time.time:0}s timeScale={Time.timeScale:0.0} night={BattleAi.IsNight()}: ");
                for (int i = 0; i < ships.Count; i++)
                {
                    var s = ships[i]; if (s == null) continue;
                    string st = s.isSinking || s.isDead ? "sunk" : s.IsSurrendered ? "surrendered" : (s.division != null && (s.division.isRetreating || s.division.retreat)) ? "retreating" : "active";
                    float dmg = 0f; try { dmg = s.DamageEstimation(); } catch { }
                    sb.Append($"[{(s.player != null && s.player.isMain ? "P" : "AI")} {s.shipType.name} {s.name} {st} dmg {dmg:0.00}] ");
                }
                Log(sb.ToString());
            }
            catch (Exception e) { Log("summary: " + e.Message); }
        }
    }
}
